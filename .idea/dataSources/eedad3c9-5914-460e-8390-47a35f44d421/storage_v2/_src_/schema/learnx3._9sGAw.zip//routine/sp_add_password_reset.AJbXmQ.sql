create
    definer = jegljiphjm@`%` procedure sp_add_password_reset(IN p_email varchar(255), IN p_token varchar(255))
BEGIN
    -- Delete any previous password_reset
    DELETE FROM password_reset WHERE email = p_email;
    -- Create a new password_reset
    INSERT INTO password_reset (email, token) VALUES (p_email, p_token);
END;

