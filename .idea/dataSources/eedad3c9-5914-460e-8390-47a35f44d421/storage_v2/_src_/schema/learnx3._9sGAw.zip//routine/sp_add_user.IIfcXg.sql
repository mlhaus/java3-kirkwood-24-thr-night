create
    definer = jegljiphjm@`%` procedure sp_add_user(IN p_email varchar(255), IN p_password varchar(255))
BEGIN
    -- Create new User record
    INSERT INTO user (email, password)
    VALUES (p_email,p_password);
    -- Get the user's id
    SET @last_user_id = LAST_INSERT_ID();
    -- Generate a random 6 digit code
    SET @code=LPAD(FLOOR(RAND() * 999999.99), 6, '0');
    -- Create new 2 Factor Authentication Code
    INSERT INTO 2fa_code (user_id, code, method) VALUES (@last_user_id, @code, 'email');
END;

