create
    definer = jegljiphjm@`%` procedure sp_get_2fa_code(IN p_email varchar(255))
BEGIN
    SELECT email, code, 2fa_code.created_at
    FROM user JOIN 2fa_code
    ON user.id = 2fa_code.user_id
    WHERE email = p_email;
END;

