create
    definer = jegljiphjm@`%` procedure sp_update_user(IN p_id int, IN p_first_name varchar(255),
                                                      IN p_last_name varchar(255), IN p_email varchar(255),
                                                      IN p_phone varchar(255), IN p_language varchar(255),
                                                      IN p_status varchar(255), IN p_privileges varchar(255),
                                                      IN p_last_logged_in datetime)
BEGIN
    UPDATE user
    SET first_name =  p_first_name,
        last_name =  p_last_name,
        email =  p_email,
        phone =  p_phone,
        language =  p_language,
        status = p_status,
        privileges = p_privileges,
        last_logged_in = p_last_logged_in
    WHERE id = p_id;
END;

